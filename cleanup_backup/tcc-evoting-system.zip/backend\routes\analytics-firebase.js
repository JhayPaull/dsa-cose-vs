const express = require('express');
const { db, COLLECTIONS, convertTimestamp } = require('../config/database-firebase');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Get analytics data
router.get('/data', authenticateToken, async (req, res) => {
    try {
        // Get total votes
        const votesSnapshot = await db.collection(COLLECTIONS.VOTES).get();
        const totalVotes = votesSnapshot.size;

        // Get registered voters
        const votersSnapshot = await db.collection(COLLECTIONS.USERS)
            .where('role', '==', 'voter')
            .get();
        const registeredVoters = votersSnapshot.size;

        // Calculate voter turnout
        const voterTurnout = registeredVoters > 0 ? Math.round((totalVotes / registeredVoters) * 100) : 0;

        // Get election status
        const electionsSnapshot = await db.collection(COLLECTIONS.ELECTIONS)
            .where('status', '==', 'active')
            .limit(1)
            .get();
        const electionStatus = !electionsSnapshot.empty ? electionsSnapshot.docs[0].data().status : 'No Active Election';

        // Get all votes with candidate info
        const votesSnapshot2 = await db.collection(COLLECTIONS.VOTES).get();
        const candidateVoteCounts = {};

        for (const voteDoc of votesSnapshot2.docs) {
            const vote = voteDoc.data();
            const candidateId = vote.candidate_id;
            candidateVoteCounts[candidateId] = (candidateVoteCounts[candidateId] || 0) + 1;
        }

        // Get candidates and their vote counts
        const candidatesSnapshot = await db.collection(COLLECTIONS.CANDIDATES).get();
        const voteDistribution = [];
        const candidates = [];

        for (const candidateDoc of candidatesSnapshot.docs) {
            const candidate = { id: candidateDoc.id, ...candidateDoc.data() };
            const votes = candidateVoteCounts[candidate.id] || 0;
            
            voteDistribution.push({
                candidate: candidate.name,
                position: candidate.position,
                votes: votes
            });

            candidates.push({
                name: candidate.name,
                position: candidate.position,
                votes: votes
            });
        }

        // Get voting trends (last 24 hours by hour)
        const oneDayAgo = new Date();
        oneDayAgo.setHours(oneDayAgo.getHours() - 24);

        const recentVotesSnapshot = await db.collection(COLLECTIONS.VOTES)
            .where('created_at', '>=', oneDayAgo)
            .get();

        const hourlyVotes = {};
        recentVotesSnapshot.docs.forEach(doc => {
            const vote = doc.data();
            const timestamp = convertTimestamp(vote.created_at);
            const hour = timestamp.getHours();
            const hourKey = `${hour.toString().padStart(2, '0')}:00`;
            hourlyVotes[hourKey] = (hourlyVotes[hourKey] || 0) + 1;
        });

        const votingTrends = Object.keys(hourlyVotes).sort().map(time => ({
            time,
            count: hourlyVotes[time]
        }));

        // Get turnout data (by day for last 7 days)
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

        const weekVotesSnapshot = await db.collection(COLLECTIONS.VOTES)
            .where('created_at', '>=', sevenDaysAgo)
            .get();

        const dailyVotes = {};
        weekVotesSnapshot.docs.forEach(doc => {
            const vote = doc.data();
            const timestamp = convertTimestamp(vote.created_at);
            const dateKey = timestamp.toISOString().split('T')[0];
            dailyVotes[dateKey] = (dailyVotes[dateKey] || 0) + 1;
        });

        const turnoutData = Object.keys(dailyVotes).sort().map(period => ({
            period,
            count: dailyVotes[period],
            percentage: registeredVoters > 0 ? Math.round((dailyVotes[period] / registeredVoters) * 100 * 100) / 100 : 0
        }));

        res.json({
            totalVotes,
            registeredVoters,
            voterTurnout,
            electionStatus,
            voteDistribution,
            votingTrends,
            turnoutData,
            candidates
        });
    } catch (error) {
        console.error('Analytics error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Export report
router.get('/export', authenticateToken, async (req, res) => {
    try {
        const votesSnapshot = await db.collection(COLLECTIONS.VOTES).get();
        const candidateVoteCounts = {};

        votesSnapshot.docs.forEach(doc => {
            const vote = doc.data();
            const candidateId = vote.candidate_id;
            candidateVoteCounts[candidateId] = (candidateVoteCounts[candidateId] || 0) + 1;
        });

        const candidatesSnapshot = await db.collection(COLLECTIONS.CANDIDATES).get();
        const totalVotes = votesSnapshot.size;
        const analytics = [];

        for (const candidateDoc of candidatesSnapshot.docs) {
            const candidate = candidateDoc.data();
            const votes = candidateVoteCounts[candidateDoc.id] || 0;
            const percentage = totalVotes > 0 ? Math.round((votes / totalVotes) * 100 * 100) / 100 : 0;

            analytics.push({
                candidate: candidate.name,
                position: candidate.position,
                votes: votes,
                percentage: percentage
            });
        }

        res.json({
            report: 'Election Report',
            generatedAt: new Date().toISOString(),
            data: analytics
        });
    } catch (error) {
        console.error('Export error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;


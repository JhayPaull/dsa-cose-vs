// Authentication JavaScript

// Use the deployed backend URL or localhost for development
// Updated to handle different environments and deployment scenarios
const API_BASE_URL = (function() {
    if (window.location.hostname === 'dsa-cose-vs.web.app' || 
        window.location.hostname === 'dsa-cose-vs.firebaseapp.com') {
        // For production when deployed to Firebase Hosting
        // We'll need to deploy the backend separately and update this
        return '/api'; // Updated to use relative path
    } else {
        // For local development, use relative path
        return '/api';
    }
})();

// Improved error handling function
async function handleFetchError(response, defaultMessage) {
    try {
        const data = await response.json();
        return data.message || defaultMessage;
    } catch (e) {
        return defaultMessage;
    }
}

// Wait for DOM to load
document.addEventListener('DOMContentLoaded', function() {
    // Registration Form Handler
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        // Handle middle initial toggle button
        const toggleButton = document.getElementById('toggleMiddleInitial');
        const middleInitialInput = document.getElementById('middleInitial');
        
        if (toggleButton && middleInitialInput) {
            toggleButton.addEventListener('click', function() {
                if (middleInitialInput.disabled) {
                    // Enable the input
                    middleInitialInput.disabled = false;
                    middleInitialInput.value = '';
                    toggleButton.textContent = 'No Middle Name';
                    toggleButton.classList.remove('btn-primary');
                    toggleButton.classList.add('btn-secondary');
                } else {
                    // Disable the input
                    middleInitialInput.disabled = true;
                    middleInitialInput.value = '';
                    toggleButton.textContent = 'Add Middle Name';
                    toggleButton.classList.remove('btn-secondary');
                    toggleButton.classList.add('btn-primary');
                }
            });
        }
        
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = {
                lastName: document.getElementById('lastName').value,
                firstName: document.getElementById('firstName').value,
                middleInitial: document.getElementById('middleInitial').value,
                year: document.getElementById('year').value,
                section: document.getElementById('section').value,
                department: document.getElementById('department').value,
                studentId: document.getElementById('studentId').value,
                email: document.getElementById('email').value,
                password: document.getElementById('password').value,
                confirmPassword: document.getElementById('confirmPassword').value
            };
            
            // Construct full name from parts (handle optional middle initial)
            const fullName = formData.middleInitial 
                ? `${formData.firstName} ${formData.middleInitial} ${formData.lastName}`
                : `${formData.firstName} ${formData.lastName}`;
            
            // Validate passwords match
            if (formData.password !== formData.confirmPassword) {
                showMessage('registerMessage', 'Passwords do not match', 'error');
                return;
            }
            
            // Validate password length
            if (formData.password.length < 6) {
                showMessage('registerMessage', 'Password must be at least 6 characters', 'error');
                return;
            }
            
            // Add full name to form data
            const submissionData = {
                ...formData,
                fullName: fullName
            };
            
            try {
                const response = await fetch(`${API_BASE_URL}/auth/register`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(submissionData)
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    showMessage('registerMessage', 'Registration successful! Logging you in...', 'success');
                    // After successful registration, login the user automatically and redirect to dashboard
                    setTimeout(async () => {
                        try {
                            const loginResponse = await fetch(`${API_BASE_URL}/auth/login`, {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({
                                    email: formData.email,
                                    password: formData.password
                                })
                            });
                            
                            const loginData = await loginResponse.json();
                            
                            if (loginResponse.ok) {
                                // Store token and user info
                                localStorage.setItem('token', loginData.token);
                                localStorage.setItem('user', JSON.stringify(loginData.user));
                                
                                // Redirect to dashboard
                                window.location.href = '/dashboard/';
                            } else {
                                // If auto-login fails, redirect to login page
                                showMessage('registerMessage', loginData.message || 'Auto-login failed. Please login manually.', 'error');
                                setTimeout(() => {
                                    window.location.href = '/auth/login/';
                                }, 2000);
                            }
                        } catch (loginError) {
                            console.error('Auto-login error:', loginError);
                            // If auto-login fails, redirect to login page
                            showMessage('registerMessage', 'Auto-login failed. Please login manually.', 'error');
                            setTimeout(() => {
                                window.location.href = '/auth/login/';
                            }, 2000);
                        }
                    }, 2000);
                } else {
                    showMessage('registerMessage', data.message || 'Registration failed', 'error');
                }
            } catch (error) {
                console.error('Registration error:', error);
                showMessage('registerMessage', 'Network error. Please check your connection and make sure the backend server is properly deployed and accessible.', 'error');
            }
        });
    }

    // Login Form Handler
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = {
                email: document.getElementById('email').value,
                password: document.getElementById('password').value,
                rememberMe: document.getElementById('rememberMe') ? document.getElementById('rememberMe').checked : false
            };
            
            try {
                showMessage('loginMessage', 'Logging in...', 'info');
                
                const response = await fetch(`${API_BASE_URL}/auth/login`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    // Store token and user info
                    localStorage.setItem('token', data.token);
                    localStorage.setItem('user', JSON.stringify(data.user));
                    
                    showMessage('loginMessage', 'Login successful! Redirecting...', 'success');
                    setTimeout(() => {
                        window.location.href = '/dashboard/';
                    }, 1000);
                } else {
                    showMessage('loginMessage', data.message || 'Login failed', 'error');
                }
            } catch (error) {
                console.error('Login error:', error);
                showMessage('loginMessage', 'Network error. Please check your connection and make sure the backend server is properly deployed and accessible.', 'error');
            }
        });
    }

    // Check if user is already logged in
    checkAuth();
});

// Show message function
function showMessage(elementId, message, type) {
    const messageEl = document.getElementById(elementId);
    if (messageEl) {
        messageEl.textContent = message;
        messageEl.className = `message ${type}`;
        // Auto-hide success messages after 5 seconds
        if (type === 'success') {
            setTimeout(() => {
                messageEl.className = 'message';
                messageEl.textContent = '';
            }, 5000);
        }
    }
}

// Check if user is already logged in
function checkAuth() {
    const token = localStorage.getItem('token');
    if (token && (window.location.pathname.includes('/auth/login/') || window.location.pathname.includes('/auth/register/'))) {
        window.location.href = '/dashboard/';
    }
}
const express = require('express');
const { db, COLLECTIONS, convertTimestamp } = require('../config/database-firebase');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Get dashboard stats
router.get('/stats', authenticateToken, async (req, res) => {
    try {
        // Get total voters
        const votersSnapshot = await db.collection(COLLECTIONS.USERS)
            .where('role', '==', 'voter')
            .get();
        const totalVoters = votersSnapshot.size;

        // Get total votes cast
        const votesSnapshot = await db.collection(COLLECTIONS.VOTES).get();
        const votesCast = votesSnapshot.size;

        // Calculate turnout rate
        const turnoutRate = totalVoters > 0 ? Math.round((votesCast / totalVoters) * 100) : 0;

        // Get active election
        const electionsSnapshot = await db.collection(COLLECTIONS.ELECTIONS)
            .where('status', '==', 'active')
            .orderBy('end_date', 'desc')
            .limit(1)
            .get();

        let timeRemaining = '--:--';
        if (!electionsSnapshot.empty) {
            const election = electionsSnapshot.docs[0].data();
            const endDate = convertTimestamp(election.end_date).toDate();
            const now = new Date();
            const diff = endDate - now;

            if (diff > 0) {
                const hours = Math.floor(diff / (1000 * 60 * 60));
                const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                timeRemaining = `${hours}:${minutes.toString().padStart(2, '0')}`;
            } else {
                timeRemaining = 'Ended';
            }
        }

        // Get recent activity (last 5 votes)
        const recentVotesSnapshot = await db.collection(COLLECTIONS.VOTES)
            .orderBy('created_at', 'desc')
            .limit(5)
            .get();

        const activities = recentVotesSnapshot.docs.map(doc => {
            const data = doc.data();
            return {
                title: 'Vote Cast',
                description: 'A vote was cast in the election',
                timestamp: convertTimestamp(data.created_at)
            };
        });

        res.json({
            totalVoters,
            votesCast,
            turnoutRate,
            timeRemaining,
            recentActivity: activities
        });
    } catch (error) {
        console.error('Dashboard stats error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;


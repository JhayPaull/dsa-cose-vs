const express = require('express');
const cors = require('cors');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
require('dotenv').config();

const app = express();
const server = http.createServer(app);

// Configure CORS for Express app

const corsOptions = {
    origin: function (origin, callback) {
        // Allow requests with no origin (like mobile apps or curl requests)
        if (!origin) return callback(null, true);
        
        // List of allowed origins
        const allowedOrigins = [
            'http://localhost:8000',
            'http://127.0.0.1:8000',
            'http://localhost:8080',
            'http://127.0.0.1:8080',
            'http://localhost:3000',
            'http://localhost:3001',
            'https://dsa-cose-vs.web.app',
            'https://dsa-cose-vs.firebaseapp.com'
        ];
        
        if (allowedOrigins.indexOf(origin) !== -1) {
            callback(null, true);
        } else {
            callback(new Error('Not allowed by CORS'));
        }
    },
    credentials: true,
    optionsSuccessStatus: 200
};

// Configure Socket.IO with error handling
const io = socketIo(server, {
    cors: corsOptions
});

// Middleware
app.use(cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Log all incoming requests for debugging
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path} - from ${req.ip}`);
    next();
});

// Initialize Firebase
let useFirebase = true; // Enable Firebase by default
let firebaseInitialized = false;
try {
    // Try to initialize Firebase
    const { initializeDatabase } = require('./config/database-firebase');
    initializeDatabase();
    console.log('Firebase initialized successfully');
    useFirebase = true;
    firebaseInitialized = true;
} catch (error) {
    console.error('Firebase initialization failed:', error.message);
    console.log('Falling back to local storage');
    useFirebase = false;
    firebaseInitialized = false;
}

// Import routes (only Firebase versions now)
const authRoutes = require('./routes/auth-local');
const dashboardRoutes = require('./routes/dashboard-firebase');
const analyticsRoutes = require('./routes/analytics-firebase');
const notificationRoutes = require('./routes/notifications-firebase');
const votingRoutes = require('./routes/voting-firebase');

console.log('Using local routes for authentication, Firebase routes for other endpoints');

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/voting', votingRoutes);

// Health check
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'OK', 
        message: 'TCC E-Voting API is running',
        database: useFirebase ? 'Firebase' : 'Local',
        timestamp: new Date().toISOString()
    });
});

// Serve frontend routes
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Real-time vote updates via Socket.IO
io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    
    socket.on('subscribe-votes', () => {
        socket.join('vote-updates');
    });
    
    socket.on('disconnect', () => {
        console.log('Client disconnected:', socket.id);
    });
});

// Make io available to routes
app.set('io', io);

// Get port from environment or use default
const PORT = process.env.PORT || 3001;

// Handle server startup with port fallback (limit retries)
let retryCount = 0;
const maxRetries = 10;

function startServer(port) {
    server.listen(port, () => {
        console.log(`Server running on port ${port}`);
        console.log(`Database backend: Firebase`);
        console.log(`CORS enabled for origins: http://localhost:8000, http://localhost:8080, http://localhost:3000, http://localhost:3001, https://dsa-cose-vs.web.app, https://dsa-cose-vs.firebaseapp.com`);
        console.log(`Serving static files from: ${path.join(__dirname, 'public')}`);
    }).on('error', (err) => {
        if (err.code === 'EADDRINUSE') {
            retryCount++;
            if (retryCount <= maxRetries) {
                console.log(`Port ${port} is busy, trying ${port + retryCount}`);
                setTimeout(() => startServer(port + retryCount), 1000);
            } else {
                console.error(`Unable to start server after ${maxRetries} attempts. Please free up port ${port} or specify a different port.`);
                process.exit(1);
            }
        } else {
            console.error('Server error:', err);
            process.exit(1);
        }
    });
}

startServer(PORT);
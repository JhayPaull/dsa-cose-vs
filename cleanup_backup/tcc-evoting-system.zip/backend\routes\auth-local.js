const express = require('express');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');
const { generateToken } = require('../middleware/auth');

const router = express.Router();

// Mock users file path
const MOCK_USERS_FILE = path.join(__dirname, '..', '..', 'mock-users.json');

// Helper function to read mock users
function readMockUsers() {
    try {
        if (fs.existsSync(MOCK_USERS_FILE)) {
            const fileContent = fs.readFileSync(MOCK_USERS_FILE, 'utf8');
            return JSON.parse(fileContent);
        }
    } catch (error) {
        console.error('Error reading mock users file:', error.message);
    }
    return [];
}

// Login with local mock users as fallback
router.post('/login', async (req, res) => {
    try {
        console.log('Login request body:', req.body);
        console.log('Login content-type:', req.get('Content-Type'));
        
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ message: 'Email and password are required' });
        }

        // Try to find user in mock users file
        const users = readMockUsers();
        const user = users.find(u => u.email === email);

        if (!user) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        // For mock users, we're storing plain text passwords
        // In a real app, these would be hashed
        const isValidPassword = user.password === password;

        if (!isValidPassword) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        // Generate token
        const token = generateToken(user);

        // Return user data (without password)
        const { password: _, ...userWithoutPassword } = user;

        return res.json({
            message: 'Login successful',
            token,
            user: userWithoutPassword
        });
    } catch (error) {
        console.error('Login error:', error);
        return res.status(500).json({ 
            message: 'Server error during login. Please try again later.',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

// Get current user (simplified for mock users)
router.get('/me', async (req, res) => {
    try {
        // Extract token from Authorization header
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ message: 'Access token required' });
        }

        // For mock implementation, we'll just return a success response
        // In a real app, you would verify the token and return user data
        
        // Try to find user in mock users file
        const users = readMockUsers();
        const user = users[0]; // Return the first user (our admin)
        
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Return user data (without password)
        const { password: _, ...userWithoutPassword } = user;

        return res.json({ 
            user: userWithoutPassword
        });
    } catch (error) {
        console.error('Get user error:', error);
        return res.status(500).json({ 
            message: 'Server error retrieving user information. Please try again later.',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

// Login with local mock users as fallback
router.post('/create-admin', async (req, res) => {
    try {
        console.log('Received request body:', req.body);
        console.log('Request content-type:', req.get('Content-Type'));
        
        const { 
            lastName, 
            firstName, 
            middleInitial, 
            year, 
            section, 
            department, 
            studentId, 
            email, 
            password
        } = req.body;

        // Validate input
        if (!lastName || !firstName || !year || !section || 
            !department || !studentId || !email || !password) {
            return res.status(400).json({ message: 'All fields are required' });
        }

        // Check if user already exists in mock file
        let users = readMockUsers();
        const existingUser = users.find(u => u.email === email || u.student_id === studentId);
        
        if (existingUser) {
            return res.status(400).json({ message: 'User already exists with this email or student ID' });
        }

        // Create admin user document
        const userData = {
            id: `mock_${Date.now()}`,
            last_name: lastName,
            first_name: firstName,
            middle_initial: middleInitial || '',
            year: year,
            section: section,
            department: department,
            full_name: middleInitial 
                ? `${firstName} ${middleInitial} ${lastName}` 
                : `${firstName} ${lastName}`,
            student_id: studentId,
            email: email,
            password: password, // In a real app, this would be hashed
            role: 'admin', // Force role to admin for this endpoint
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        };

        // Add to users array
        users.push(userData);
        
        // Save to file
        try {
            fs.writeFileSync(MOCK_USERS_FILE, JSON.stringify(users, null, 2));
        } catch (saveError) {
            console.error('Error saving mock user:', saveError);
            return res.status(500).json({ 
                message: 'Failed to save admin account. Please try again later.',
                error: process.env.NODE_ENV === 'development' ? saveError.message : undefined
            });
        }

        return res.status(201).json({ 
            message: 'Admin account created successfully',
            userId: userData.id
        });
    } catch (error) {
        console.error('Admin creation error:', error);
        return res.status(500).json({ 
            message: 'Server error during admin creation. Please try again later.',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

module.exports = router;
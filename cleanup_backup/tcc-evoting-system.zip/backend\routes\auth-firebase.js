const express = require('express');
const bcrypt = require('bcryptjs');
const { db, COLLECTIONS, toFirestoreTimestamp } = require('../config/database-firebase');
const { generateToken, authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Register
router.post('/register', async (req, res) => {
    try {
        // Updated to include new fields without role
        const { 
            lastName, 
            firstName, 
            middleInitial, 
            year, 
            section, 
            department, 
            studentId, 
            email, 
            password,
            fullName // Added full name
        } = req.body;

        // Validate required input fields (middleInitial is now optional)
        if (!lastName || !firstName || !year || !section || 
            !department || !studentId || !email || !password) {
            return res.status(400).json({ message: 'All required fields must be filled' });
        }

        // Check if user already exists
        try {
            const usersRef = db.collection(COLLECTIONS.USERS);
            const emailQuery = await usersRef.where('email', '==', email).get();
            const studentIdQuery = await usersRef.where('student_id', '==', studentId).get();

            if (!emailQuery.empty || !studentIdQuery.empty) {
                return res.status(400).json({ message: 'User already exists with this email or student ID' });
            }
        } catch (queryError) {
            console.error('Query error during registration:', queryError);
            // Continue with registration even if we can't verify existence
            // This prevents blocking registration due to Firestore issues
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create user document with all new fields, default role is 'voter'
        const userData = {
            last_name: lastName,
            first_name: firstName,
            middle_initial: middleInitial || '', // Handle optional middle name/initial
            year: year,
            section: section,
            department: department,
            full_name: fullName || (middleInitial 
                ? `${firstName} ${middleInitial} ${lastName}` 
                : `${firstName} ${lastName}`), // Handle optional middle name/initial in full name
            student_id: studentId,
            email: email,
            password: hashedPassword,
            role: 'voter', // All users are voters by default
            created_at: toFirestoreTimestamp(new Date()),
            updated_at: toFirestoreTimestamp(new Date())
        };

        // Try to create the user
        try {
            const userRef = await db.collection(COLLECTIONS.USERS).add(userData);
            const userId = userRef.id;

            // Try to create welcome notification (non-critical)
            try {
                await db.collection(COLLECTIONS.NOTIFICATIONS).add({
                    user_id: userId,
                    title: 'Welcome to TCC E-Voting System',
                    message: 'Your account has been successfully created. You can now participate in the election.',
                    type: 'success',
                    read: false,
                    created_at: toFirestoreTimestamp(new Date())
                });
            } catch (notificationError) {
                console.error('Non-critical error creating notification:', notificationError);
                // Continue even if notification fails
            }

            return res.status(201).json({ 
                message: 'Registration successful',
                userId: userId
            });
        } catch (creationError) {
            console.error('User creation error:', creationError);
            return res.status(500).json({ 
                message: 'Failed to create user account. Please try again later.',
                error: process.env.NODE_ENV === 'development' ? creationError.message : undefined
            });
        }
    } catch (error) {
        console.error('Registration error:', error);
        return res.status(500).json({ 
            message: 'Server error during registration. Please try again later.',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

// Special endpoint to create admin account
router.post('/create-admin', async (req, res) => {
    try {
        const { 
            lastName, 
            firstName, 
            middleInitial, 
            year, 
            section, 
            department, 
            studentId, 
            email, 
            password
        } = req.body;

        // Validate input
        if (!lastName || !firstName || !year || !section || 
            !department || !studentId || !email || !password) {
            return res.status(400).json({ message: 'All fields are required' });
        }

        // Check if user already exists
        try {
            const usersRef = db.collection(COLLECTIONS.USERS);
            const emailQuery = await usersRef.where('email', '==', email).get();
            const studentIdQuery = await usersRef.where('student_id', '==', studentId).get();

            if (!emailQuery.empty || !studentIdQuery.empty) {
                return res.status(400).json({ message: 'User already exists with this email or student ID' });
            }
        } catch (queryError) {
            console.error('Query error during admin creation:', queryError);
            // Continue with admin creation even if we can't verify existence
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create admin user document
        const userData = {
            last_name: lastName,
            first_name: firstName,
            middle_initial: middleInitial || '',
            year: year,
            section: section,
            department: department,
            full_name: middleInitial 
                ? `${firstName} ${middleInitial} ${lastName}` 
                : `${firstName} ${lastName}`,
            student_id: studentId,
            email: email,
            password: hashedPassword,
            role: 'admin', // Force role to admin for this endpoint
            created_at: toFirestoreTimestamp(new Date()),
            updated_at: toFirestoreTimestamp(new Date())
        };

        // Try to create the admin user
        try {
            const userRef = await db.collection(COLLECTIONS.USERS).add(userData);
            const userId = userRef.id;

            // Try to create welcome notification (non-critical)
            try {
                await db.collection(COLLECTIONS.NOTIFICATIONS).add({
                    user_id: userId,
                    title: 'Welcome Admin!',
                    message: 'Your admin account has been successfully created.',
                    type: 'success',
                    read: false,
                    created_at: toFirestoreTimestamp(new Date())
                });
            } catch (notificationError) {
                console.error('Non-critical error creating admin notification:', notificationError);
                // Continue even if notification fails
            }

            return res.status(201).json({ 
                message: 'Admin account created successfully',
                userId: userId
            });
        } catch (creationError) {
            console.error('Admin creation error:', creationError);
            return res.status(500).json({ 
                message: 'Failed to create admin account. Please try again later.',
                error: process.env.NODE_ENV === 'development' ? creationError.message : undefined
            });
        }
    } catch (error) {
        console.error('Admin creation error:', error);
        return res.status(500).json({ 
            message: 'Server error during admin creation. Please try again later.',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

// Login
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ message: 'Email and password are required' });
        }

        // Find user by email or student ID
        try {
            const usersRef = db.collection(COLLECTIONS.USERS);
            const emailQuery = await usersRef.where('email', '==', email).get();
            const studentIdQuery = await usersRef.where('student_id', '==', email).get();

            let userDoc = null;
            let userId = null;

            if (!emailQuery.empty) {
                userDoc = emailQuery.docs[0];
                userId = userDoc.id;
            } else if (!studentIdQuery.empty) {
                userDoc = studentIdQuery.docs[0];
                userId = userDoc.id;
            }

            if (!userDoc) {
                return res.status(401).json({ message: 'Invalid credentials' });
            }

            const user = { id: userId, ...userDoc.data() };

            // Verify password
            const isValidPassword = await bcrypt.compare(password, user.password);

            if (!isValidPassword) {
                return res.status(401).json({ message: 'Invalid credentials' });
            }

            // Generate token
            const token = generateToken(user);

            // Return user data (without password)
            const { password: _, ...userWithoutPassword } = user;

            return res.json({
                message: 'Login successful',
                token,
                user: userWithoutPassword
            });
        } catch (queryError) {
            console.error('Database query error during login:', queryError);
            return res.status(500).json({ 
                message: 'Unable to access user database. Please try again later.',
                error: process.env.NODE_ENV === 'development' ? queryError.message : undefined
            });
        }
    } catch (error) {
        console.error('Login error:', error);
        return res.status(500).json({ 
            message: 'Server error during login. Please try again later.',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

// Get current user
router.get('/me', authenticateToken, async (req, res) => {
    try {
        try {
            const userDoc = await db.collection(COLLECTIONS.USERS).doc(req.user.id).get();

            if (!userDoc.exists) {
                return res.status(404).json({ message: 'User not found' });
            }

            const userData = userDoc.data();
            const { password, ...userWithoutPassword } = userData;

            return res.json({ 
                user: {
                    id: userDoc.id,
                    ...userWithoutPassword
                }
            });
        } catch (queryError) {
            console.error('Database query error getting user:', queryError);
            return res.status(500).json({ 
                message: 'Unable to retrieve user information. Please try again later.',
                error: process.env.NODE_ENV === 'development' ? queryError.message : undefined
            });
        }
    } catch (error) {
        console.error('Get user error:', error);
        return res.status(500).json({ 
            message: 'Server error retrieving user information. Please try again later.',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

module.exports = router;
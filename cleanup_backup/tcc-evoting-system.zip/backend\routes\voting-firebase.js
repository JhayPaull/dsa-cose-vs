const express = require('express');
const { db, COLLECTIONS, toFirestoreTimestamp, convertTimestamp } = require('../config/database-firebase');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Get active elections and candidates
router.get('/elections', authenticateToken, async (req, res) => {
    try {
        // Get active elections
        const electionsSnapshot = await db.collection(COLLECTIONS.ELECTIONS)
            .where('status', '==', 'active')
            .orderBy('end_date', 'desc')
            .get();

        if (electionsSnapshot.empty) {
            return res.json({ elections: [], candidates: [] });
        }

        const elections = electionsSnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));

        const electionIds = elections.map(e => e.id);

        // Get candidates for active elections
        // Note: Firestore 'in' query is limited to 10 items, so we handle multiple elections differently
        let candidatesSnapshot;
        if (electionIds.length === 0) {
            candidatesSnapshot = { docs: [] };
        } else if (electionIds.length <= 10) {
            candidatesSnapshot = await db.collection(COLLECTIONS.CANDIDATES)
                .where('election_id', 'in', electionIds)
                .get();
        } else {
            // If more than 10 elections, get all candidates and filter
            const allCandidatesSnapshot = await db.collection(COLLECTIONS.CANDIDATES).get();
            candidatesSnapshot = {
                docs: allCandidatesSnapshot.docs.filter(doc => 
                    electionIds.includes(doc.data().election_id)
                )
            };
        }

        const candidates = candidatesSnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));

        // Check if user has already voted
        let userVotesSnapshot;
        if (electionIds.length === 0) {
            userVotesSnapshot = { docs: [] };
        } else if (electionIds.length <= 10) {
            userVotesSnapshot = await db.collection(COLLECTIONS.VOTES)
                .where('user_id', '==', req.user.id)
                .where('election_id', 'in', electionIds)
                .get();
        } else {
            // If more than 10 elections, get all user votes and filter
            const allUserVotesSnapshot = await db.collection(COLLECTIONS.VOTES)
                .where('user_id', '==', req.user.id)
                .get();
            userVotesSnapshot = {
                docs: allUserVotesSnapshot.docs.filter(doc => 
                    electionIds.includes(doc.data().election_id)
                )
            };
        }

        const votedElectionIds = userVotesSnapshot.docs.map(doc => doc.data().election_id);
        const availableElections = elections.filter(e => !votedElectionIds.includes(e.id));

        res.json({
            elections: availableElections,
            candidates: candidates,
            hasVoted: votedElectionIds.length > 0
        });
    } catch (error) {
        console.error('Get elections error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Submit vote
router.post('/vote', authenticateToken, async (req, res) => {
    try {
        const { electionId, votes } = req.body;
        const userId = req.user.id;

        if (!electionId || !votes || Object.keys(votes).length === 0) {
            return res.status(400).json({ message: 'Invalid vote data' });
        }

        // Check if election is active
        const electionDoc = await db.collection(COLLECTIONS.ELECTIONS).doc(electionId).get();
        
        if (!electionDoc.exists) {
            return res.status(400).json({ message: 'Election not found' });
        }

        const election = electionDoc.data();
        if (election.status !== 'active') {
            return res.status(400).json({ message: 'Election is not active' });
        }

        // Check if user has already voted
        const existingVoteSnapshot = await db.collection(COLLECTIONS.VOTES)
            .where('user_id', '==', userId)
            .where('election_id', '==', electionId)
            .get();

        if (!existingVoteSnapshot.empty) {
            return res.status(400).json({ message: 'You have already voted in this election' });
        }

        // Start batch write
        const batch = db.batch();
        const timestamp = toFirestoreTimestamp(new Date());

        // Insert votes and update candidate vote counts
        for (const [position, candidateId] of Object.entries(votes)) {
            // Add vote document
            const voteRef = db.collection(COLLECTIONS.VOTES).doc();
            batch.set(voteRef, {
                user_id: userId,
                election_id: electionId,
                candidate_id: candidateId,
                created_at: timestamp
            });

            // Update candidate vote count
            const candidateRef = db.collection(COLLECTIONS.CANDIDATES).doc(candidateId);
            const { admin } = require('../config/database-firebase');
            batch.update(candidateRef, {
                votes: admin.firestore.FieldValue.increment(1)
            });

            // Record in vote history
            const historyRef = db.collection(COLLECTIONS.VOTE_HISTORY).doc();
            batch.set(historyRef, {
                election_id: electionId,
                candidate_id: candidateId,
                timestamp: timestamp
            });
        }

        await batch.commit();

        // Emit real-time update via Socket.IO
        const io = req.app.get('io');
        if (io) {
            io.to('vote-updates').emit('vote-update', {
                electionId,
                timestamp: new Date()
            });
        }

        // Create notification
        await db.collection(COLLECTIONS.NOTIFICATIONS).add({
            user_id: userId,
            title: 'Vote Submitted',
            message: 'Your vote has been successfully submitted. Thank you for participating!',
            type: 'success',
            read: false,
            created_at: timestamp
        });

        res.json({ message: 'Vote submitted successfully' });
    } catch (error) {
        console.error('Vote submission error:', error);
        res.status(500).json({ message: 'Server error during vote submission' });
    }
});

module.exports = router;


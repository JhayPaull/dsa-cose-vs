# TCC E-Voting System - Unified Backend with Frontend

This is a unified version of the TCC E-Voting System where the frontend is served directly by the backend server.

## Project Structure

- `/` - Root directory
- `/public` - Frontend files (HTML, CSS, JS, images)
- `/config` - Configuration files
- `/routes` - API route handlers
- `/middleware` - Custom middleware
- `/server.js` - Main server file

## How to Run

1. Install dependencies:
   ```
   npm install
   ```

2. Start the server:
   ```
   npm start
   ```

3. Access the application at `http://localhost:3001`

## Key Changes

1. The backend now serves frontend files statically from the `/public` directory
2. All API endpoints are prefixed with `/api`
3. All frontend files use relative paths with `/` as the base
4. The frontend JavaScript files have been updated to use `/api` as the base URL for API calls
5. All navigation links in HTML files have been updated to use absolute paths

## Features

- Real-time vote tabulation
- User authentication (registration and login)
- Dashboard with statistics
- Voting interface
- Analytics and reporting
- Notifications system
- User profile management
- Responsive design for both desktop and mobile

## Technologies Used

- Node.js with Express.js for the backend
- Firebase for data storage and authentication
- HTML, CSS, JavaScript for the frontend
- Socket.IO for real-time updates
- Chart.js for data visualization
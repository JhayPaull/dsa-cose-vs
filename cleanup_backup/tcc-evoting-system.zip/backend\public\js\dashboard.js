// Dashboard JavaScript

const API_BASE_URL = '/api';

// Check authentication
function checkAuth() {
    const token = localStorage.getItem('token');
    if (!token) {
        window.location.href = '/auth/login/';
        return false;
    }
    return true;
}

// Load user info
function loadUserInfo() {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    const userNameEl = document.getElementById('userName');
    if (userNameEl && user.fullName) {
        userNameEl.textContent = user.fullName;
    }
}

// Load dashboard stats
async function loadDashboardStats() {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_BASE_URL}/dashboard/stats`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            
            document.getElementById('totalVoters').textContent = data.totalVoters || 0;
            document.getElementById('votesCast').textContent = data.votesCast || 0;
            document.getElementById('turnoutRate').textContent = `${data.turnoutRate || 0}%`;
            document.getElementById('timeRemaining').textContent = data.timeRemaining || '--:--';
            
            // Load recent activity
            loadRecentActivity(data.recentActivity || []);
        }
    } catch (error) {
        console.error('Error loading dashboard stats:', error);
    }
}

// Load recent activity
function loadRecentActivity(activities) {
    const activityList = document.getElementById('recentActivity');
    if (!activityList) return;
    
    if (activities.length === 0) {
        activityList.innerHTML = '<p class="empty-state">No recent activity</p>';
        return;
    }
    
    activityList.innerHTML = activities.map(activity => `
        <div class="activity-item">
            <strong>${activity.title}</strong>
            <p>${activity.description}</p>
            <small>${new Date(activity.timestamp).toLocaleString()}</small>
        </div>
    `).join('');
}

// Logout handler
const logoutBtn = document.getElementById('logoutBtn');
if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = '/auth/login/';
    });
}

// Mobile menu toggle
function toggleMobileMenu() {
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.getElementById('menuOverlay');
    
    if (sidebar && overlay) {
        sidebar.classList.toggle('active');
        overlay.classList.toggle('active');
    }
}

// Close mobile menu when clicking overlay
function closeMobileMenu() {
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.getElementById('menuOverlay');
    
    if (sidebar && overlay) {
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
    }
}

// Initialize dashboard
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        if (checkAuth()) {
            loadUserInfo();
            loadDashboardStats();
            // Refresh stats every 30 seconds
            setInterval(loadDashboardStats, 30000);
            
            // Mobile menu event listeners
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            const menuOverlay = document.getElementById('menuOverlay');
            
            if (mobileMenuBtn) {
                mobileMenuBtn.addEventListener('click', toggleMobileMenu);
            }
            
            if (menuOverlay) {
                menuOverlay.addEventListener('click', closeMobileMenu);
            }
        }
    });
} else {
    if (checkAuth()) {
        loadUserInfo();
        loadDashboardStats();
        setInterval(loadDashboardStats, 30000);
        
        // Mobile menu event listeners
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const menuOverlay = document.getElementById('menuOverlay');
        
        if (mobileMenuBtn) {
            mobileMenuBtn.addEventListener('click', toggleMobileMenu);
        }
        
        if (menuOverlay) {
            menuOverlay.addEventListener('click', closeMobileMenu);
        }
    }
}
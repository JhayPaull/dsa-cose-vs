// Profile JavaScript

const API_BASE_URL = '/api';

// Check authentication
function checkAuth() {
    const token = localStorage.getItem('token');
    if (!token) {
        window.location.href = '/auth/login/';
        return false;
    }
    return true;
}

// Load user profile
async function loadProfile() {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_BASE_URL}/auth/me`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            const user = data.user;
            
            // Update profile fields
            document.getElementById('profileName').textContent = user.full_name || 'User';
            document.getElementById('profileFullName').textContent = user.full_name || '-';
            document.getElementById('profileStudentId').textContent = user.student_id || '-';
            document.getElementById('profileEmail').textContent = user.email || '-';
            
            const roleBadge = document.getElementById('profileRole');
            if (roleBadge) {
                roleBadge.textContent = user.role ? user.role.charAt(0).toUpperCase() + user.role.slice(1) : 'Voter';
            }
            
            if (user.created_at) {
                const date = new Date(user.created_at);
                document.getElementById('profileCreatedAt').textContent = date.toLocaleDateString();
            }
            
            // Update header
            const userNameEl = document.getElementById('userName');
            if (userNameEl) {
                userNameEl.textContent = user.full_name || 'User';
            }
        }
    } catch (error) {
        console.error('Error loading profile:', error);
    }
}

// Logout handler
const logoutBtn = document.getElementById('logoutBtn');
if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = '/auth/login/';
    });
}

// Initialize profile
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        if (checkAuth()) {
            loadProfile();
        }
    });
} else {
    if (checkAuth()) {
        loadProfile();
    }
}
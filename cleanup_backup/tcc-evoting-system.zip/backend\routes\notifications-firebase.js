const express = require('express');
const { db, COLLECTIONS, convertTimestamp, toFirestoreTimestamp } = require('../config/database-firebase');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Get notifications
router.get('/', authenticateToken, async (req, res) => {
    try {
        const { filter = 'all' } = req.query;
        const userId = req.user.id;

        // Firestore doesn't support 'in' with null, so we need to query separately
        const userNotificationsSnapshot = await db.collection(COLLECTIONS.NOTIFICATIONS)
            .where('user_id', '==', userId)
            .get();
        
        const globalNotificationsSnapshot = await db.collection(COLLECTIONS.NOTIFICATIONS)
            .where('user_id', '==', null)
            .get();
        
        let allDocs = [...userNotificationsSnapshot.docs, ...globalNotificationsSnapshot.docs];
        
        // Apply filter
        if (filter === 'unread') {
            allDocs = allDocs.filter(doc => doc.data().read === false);
        } else if (filter === 'read') {
            allDocs = allDocs.filter(doc => doc.data().read === true);
        }
        
        // Sort by created_at descending
        allDocs.sort((a, b) => {
            const aTime = convertTimestamp(a.data().created_at);
            const bTime = convertTimestamp(b.data().created_at);
            return bTime - aTime;
        });
        
        const notifications = allDocs.slice(0, 50).map(doc => ({
            id: doc.id,
            ...doc.data(),
            createdAt: convertTimestamp(doc.data().created_at)
        }));
        
        // Get unread count
        const unreadUserSnapshot = await db.collection(COLLECTIONS.NOTIFICATIONS)
            .where('user_id', '==', userId)
            .where('read', '==', false)
            .get();
        
        const unreadGlobalSnapshot = await db.collection(COLLECTIONS.NOTIFICATIONS)
            .where('user_id', '==', null)
            .where('read', '==', false)
            .get();
        
        res.json({
            notifications,
            unreadCount: unreadUserSnapshot.size + unreadGlobalSnapshot.size
        });
    } catch (error) {
        console.error('Get notifications error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Mark notification as read
router.put('/:id/read', authenticateToken, async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.id;

        const notificationRef = db.collection(COLLECTIONS.NOTIFICATIONS).doc(id);
        const notificationDoc = await notificationRef.get();

        if (!notificationDoc.exists) {
            return res.status(404).json({ message: 'Notification not found' });
        }

        const notification = notificationDoc.data();
        if (notification.user_id && notification.user_id !== userId) {
            return res.status(403).json({ message: 'Unauthorized' });
        }

        await notificationRef.update({ read: true });

        res.json({ message: 'Notification marked as read' });
    } catch (error) {
        console.error('Mark read error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Mark all as read
router.put('/read-all', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;

        const userSnapshot = await db.collection(COLLECTIONS.NOTIFICATIONS)
            .where('user_id', '==', userId)
            .where('read', '==', false)
            .get();
        
        const globalSnapshot = await db.collection(COLLECTIONS.NOTIFICATIONS)
            .where('user_id', '==', null)
            .where('read', '==', false)
            .get();

        const batch = db.batch();
        [...userSnapshot.docs, ...globalSnapshot.docs].forEach(doc => {
            batch.update(doc.ref, { read: true });
        });
        await batch.commit();

        res.json({ message: 'All notifications marked as read' });
    } catch (error) {
        console.error('Mark all read error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Delete notification
router.delete('/:id', authenticateToken, async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.id;

        const notificationRef = db.collection(COLLECTIONS.NOTIFICATIONS).doc(id);
        const notificationDoc = await notificationRef.get();

        if (!notificationDoc.exists) {
            return res.status(404).json({ message: 'Notification not found' });
        }

        const notification = notificationDoc.data();
        if (notification.user_id && notification.user_id !== userId) {
            return res.status(403).json({ message: 'Unauthorized' });
        }

        await notificationRef.delete();

        res.json({ message: 'Notification deleted' });
    } catch (error) {
        console.error('Delete notification error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Clear all notifications
router.delete('/clear-all', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;

        const snapshot = await db.collection(COLLECTIONS.NOTIFICATIONS)
            .where('user_id', '==', userId)
            .get();

        const batch = db.batch();
        snapshot.docs.forEach(doc => {
            batch.delete(doc.ref);
        });
        await batch.commit();

        res.json({ message: 'All notifications cleared' });
    } catch (error) {
        console.error('Clear all error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;
